Floron WordPress Website Package

This ZIP includes:
- A custom basic theme scaffold (FloronTheme)
- Sample coffee and farm-related images for your WordPress media library

Instructions:
1. Upload 'FloronTheme.zip' via Appearance > Themes > Add New > Upload
2. Upload the contents of the 'images' folder via Media > Add New
3. Customize your homepage using Elementor or WordPress Editor

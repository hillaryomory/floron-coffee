<?php get_header(); ?>
<h1>Welcome to Floron Coffee Growers SACCO</h1>
<?php get_footer(); ?>